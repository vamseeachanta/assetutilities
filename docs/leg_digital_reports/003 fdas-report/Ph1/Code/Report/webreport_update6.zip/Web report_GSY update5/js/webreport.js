$(document).ready(function() {
    
    $(document).scroll(function(){
         
        var offsetPixel = 60;
         
        if($(window).scrollTop() > offsetPixel) {
             
            $('#sidenav').fadeIn();
             
        } else { 
             
            $('#sidenav').hide();
             
        }
         
    });
    
//Line Chart with CSV File
    
d3.csv('csv/money.csv', function (error, data){
    
    var dayArray = [];
    var chartwidth = 750;
    var chartheight = 550;
    
    var dataMoney = [
        
        {
            
            key: 'Money', //What do the points represent? Money etc
            values: [],
            color: '#ff7f0e'
            
        }
        
    ];
    
    data.forEach(function (d){
        
        d.Day = +d.Day;
        d.Money= +d.Money;
        
        dataMoney[0].values.push({x: d.Day, y: d.Money});
        
    });
    
    nv.addGraph(function() { //Options for the line graphs
                  var chart = nv.models.lineWithFocusChart()
                                .useInteractiveGuideline(true) 
                                .showLegend(true)
                                .showYAxis(true) 
                                .showXAxis(true)
                                .height(chartheight);
                    
                  chart.xAxis
                      .axisLabel('Day(s)');
                    //X-axis label

                  chart.yAxis     
                      .axisLabel('Money ($)');
                    //Y-axis Label
            
                  d3.select('#linechart1 svg') //This code renders the graph  
                      .datum(dataMoney)  //call the array that holds all the information      
                      .call(chart)
                        .attr('width', chartwidth).attr('height', chartheight);   //call the chart   

                  nv.utils.windowResize(function() { chart.update() });
                  return chart;
                });
    
    });
    
    //Barchart
    
    d3.csv('csv/country.csv', function(error, data){
        
        var chartwidth = 725;
        var chartheight = 550;
        var barchartData = [
            {
                
                key: "Pokemon Go Players",
                values: []
                
            }
            
        ];
        
        data.forEach(function(d){
            
            d.Value = +d.Value;
            
            barchartData[0].values.push(d)
            
        });
        
        nv.addGraph(function() {
		
   		var chart = nv.models.discreteBarChart()
       		.x(function (d) {return d.Country })
       		.y(function (d) { return d.Value })
       		.staggerLabels(true)
       		.showValues(true)
            .height(chartheight);
 
 	  	d3.select('#barchart1 svg')
    			.datum(barchartData)
       			.call(chart);
 
   		nv.utils.windowResize(chart.update);
   		return chart;
 	   });
        
    });
    
    //Line and Bar
    
    d3.csv('csv/lineandbar.csv', function(error, data){
        
        var chartwidth = 725;
        var chartheight = 550;
        var lineandbarData = [
          
            {
                
                key: "Income",
                bar: true,
                values: []
                
            },
            {
                
                key: "Spending",
                values: []
                
            }
            
        ].map(function(series){
            
            series.values = series.values.map(function(d){return {x: d[0], y: d[1]}});
            return series;
            
        });
        
        data.forEach(function(d) {
            
            d.Income = +d.Income;
            d.Spending = +d.Spending;
            d.Day = +d.Day;
            
            lineandbarData[0].values.push([d.Day, d.Income]);
            lineandbarData[1].values.push([d.Day, d.Spending]);
            
        });
        
        nv.addGraph(function(){
            
            var chart = nv.models.linePlusBarChart()
            .x(function(d,i) { return i })
            .y(function(d,i) {return d[1] })
            .height(chartheight);
            
            chart.y1Axis
          .tickFormat(d3.format(',f'));

      chart.y2Axis
          .tickFormat(function(d) { return '$' + d3.format(',f')(d) });

      d3.select('#barandlinechart1 svg')
        .datum(lineandbarData)
        .call(chart);

      nv.utils.windowResize(chart.update);

      return chart;
            
        });

        
    });
    
    function scrollToDiv(div) {
    
    $('html, body').animate({
		scrollTop: $(div).offset().top
	},1000);
    
    }
});

    